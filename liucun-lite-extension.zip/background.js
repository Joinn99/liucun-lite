chrome.action.onClicked.addListener(tab => {
  if (!/^https:\/\/www\.bilibili\.com\/(?:en\/)?video\/BV[\w]{10}/.test(tab.url || '')) {
    chrome.tabs.create({url:chrome.runtime.getURL('runner.html')}); return;
  }
  chrome.tabs.create({url:chrome.runtime.getURL(`runner.html?tab=${tab.id}`)});
});
